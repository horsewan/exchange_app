package cn.ztuo.bitrade.apns.error;

/**
 * @description: ErrorListener
 * @author: MrGao
 * @create: 2019/09/04 11:20
 */
public interface ErrorListener {
    void handle(ErrorModel var1);
}

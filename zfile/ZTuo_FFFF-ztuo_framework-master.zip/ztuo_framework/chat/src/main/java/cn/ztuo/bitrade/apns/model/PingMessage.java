package cn.ztuo.bitrade.apns.model;

/**
 * @description: PingMessage
 * @author: MrGao
 * @create: 2019/09/04 11:27
 */
public class PingMessage {

    public static final PingMessage INSTANCE = new PingMessage();

    public PingMessage() {
    }
}

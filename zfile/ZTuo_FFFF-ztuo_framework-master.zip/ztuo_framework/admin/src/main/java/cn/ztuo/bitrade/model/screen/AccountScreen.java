package cn.ztuo.bitrade.model.screen;

import lombok.Data;

@Data
public class AccountScreen {

    protected String account ;
}

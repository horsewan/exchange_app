package cn.ztuo.bitrade.dao;

import cn.ztuo.bitrade.dao.base.BaseDao;
import cn.ztuo.bitrade.entity.LegalWalletRecharge;

public interface LegalWalletRechargeDao extends BaseDao<LegalWalletRecharge> {
}

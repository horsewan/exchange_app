package cn.ztuo.bitrade.dto;

import lombok.AllArgsConstructor;
import lombok.Data;

/**
 * @author MrGao
 * @Title: ${file_name}
 * @Description:
 * @date 2018/4/289:45
 */
@Data
@AllArgsConstructor
public class CoinDTO {
    private String name;
    private String unit;
}

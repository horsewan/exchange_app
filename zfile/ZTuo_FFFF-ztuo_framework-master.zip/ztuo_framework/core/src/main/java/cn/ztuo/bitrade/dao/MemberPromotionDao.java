package cn.ztuo.bitrade.dao;

import cn.ztuo.bitrade.dao.base.BaseDao;
import cn.ztuo.bitrade.entity.MemberPromotion;

/**
 * @author GuoShuai
 * @date 2018年03月08日
 */
public interface MemberPromotionDao extends BaseDao<MemberPromotion> {
}

package cn.ztuo.bitrade.dao;

import cn.ztuo.bitrade.dao.base.BaseDao;
import cn.ztuo.bitrade.entity.GiftConfig;

/**
 * @Description:
 * @Author: GuoShuai
 * @Date: 2019/4/29 11:10 AM
 */
public interface GiftConfigDao extends BaseDao<GiftConfig> {
}

package cn.ztuo.bitrade.dao;

import cn.ztuo.bitrade.dao.base.BaseDao;
import cn.ztuo.bitrade.entity.Feedback;

/**
 * @author GuoShuai
 * @date 2018年03月19日
 */
public interface FeedbackDao extends BaseDao<Feedback> {
}

package cn.ztuo.bitrade.dao;

import cn.ztuo.bitrade.dao.base.BaseDao;
import cn.ztuo.bitrade.entity.MemberSignRecord;

/**
 * @author MrGao
 * @Description:
 * @date 2018/5/410:18
 */
public interface MemberSignRecordDao extends BaseDao<MemberSignRecord> {
}

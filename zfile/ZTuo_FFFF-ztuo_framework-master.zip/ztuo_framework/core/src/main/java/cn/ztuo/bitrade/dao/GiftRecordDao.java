package cn.ztuo.bitrade.dao;

import cn.ztuo.bitrade.dao.base.BaseDao;
import cn.ztuo.bitrade.entity.GiftRecord;

/**
 * @Description:
 * @Author: GuoShuai
 * @Date: 2019/4/29 11:10 AM
 */
public interface GiftRecordDao extends BaseDao<GiftRecord> {
}

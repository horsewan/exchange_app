package cn.ztuo.bitrade.dao;

import cn.ztuo.bitrade.dao.base.BaseDao;
import cn.ztuo.bitrade.entity.AdminAccessLog;

/**
 * @author GuoShuai
 * @date 2017年12月19日
 */
public interface AdminAccessLogDao extends BaseDao<AdminAccessLog> {

}

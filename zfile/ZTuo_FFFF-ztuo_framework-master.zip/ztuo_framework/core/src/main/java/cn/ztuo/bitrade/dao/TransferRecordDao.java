package cn.ztuo.bitrade.dao;

import cn.ztuo.bitrade.dao.base.BaseDao;
import cn.ztuo.bitrade.entity.TransferRecord;

/**
 * @author GuoShuai
 * @date 2018年02月27日
 */
public interface TransferRecordDao extends BaseDao<TransferRecord> {
}

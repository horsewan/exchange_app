package cn.ztuo.bitrade.dao;

import cn.ztuo.bitrade.dao.base.BaseDao;
import cn.ztuo.bitrade.entity.Department;

/**
 * @author GuoShuai
 * @date 2017年12月18日
 */
public interface DepartmentDao extends BaseDao<Department> {
}

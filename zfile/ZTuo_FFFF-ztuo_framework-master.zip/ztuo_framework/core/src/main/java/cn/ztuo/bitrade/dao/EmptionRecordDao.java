package cn.ztuo.bitrade.dao;

import cn.ztuo.bitrade.dao.base.BaseDao;
import cn.ztuo.bitrade.entity.EmptionRecord;

/**
 * @author gs
 */
public interface EmptionRecordDao extends BaseDao<EmptionRecord>{



}
package cn.ztuo.bitrade.constant;

public enum Symbol {
    USDT,BTC,ETH,GCC,GCX;
}

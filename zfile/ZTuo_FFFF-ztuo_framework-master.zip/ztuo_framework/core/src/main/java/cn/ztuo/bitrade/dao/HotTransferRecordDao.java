package cn.ztuo.bitrade.dao;

        import cn.ztuo.bitrade.dao.base.BaseDao;
        import cn.ztuo.bitrade.entity.HotTransferRecord;

public interface HotTransferRecordDao extends BaseDao<HotTransferRecord> {
}

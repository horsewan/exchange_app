package cn.ztuo.bitrade.dao;

import cn.ztuo.bitrade.dao.base.BaseDao;
import cn.ztuo.bitrade.entity.WebsiteInformation;

/**
 * @author MrGao
 * @description
 * @date 2018/1/25 18:22
 */
public interface WebsiteInformationDao extends BaseDao<WebsiteInformation> {
}

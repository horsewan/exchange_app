package cn.ztuo.bitrade.dao;

import cn.ztuo.bitrade.dao.base.BaseDao;
import cn.ztuo.bitrade.entity.MemberApplicationConfig;

public interface MemberApplicationConfigDao extends BaseDao<MemberApplicationConfig> {
}

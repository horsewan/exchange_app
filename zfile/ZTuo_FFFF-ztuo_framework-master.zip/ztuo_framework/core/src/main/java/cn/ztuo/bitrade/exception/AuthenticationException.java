package cn.ztuo.bitrade.exception;

public class AuthenticationException extends Exception {

	public AuthenticationException(String msg) {
		super(msg);
	}

}

package cn.ztuo.bitrade.dao;

import cn.ztuo.bitrade.dao.base.BaseDao;
import cn.ztuo.bitrade.entity.LegalWalletWithdraw;

public interface LegalWalletWithdrawDao extends BaseDao<LegalWalletWithdraw> {
}

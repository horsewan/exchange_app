package cn.ztuo.bitrade.constant;

/**
 * @author MrGao
 * @Description:
 * @date 2018/5/311:33
 */
public enum SignStatus {
    UNDERWAY, FINISH;
}

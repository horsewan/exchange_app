<template>
  <div class="container">
    <!-- <img src="../../assets/images/call.png"> -->
    <div class="content-wrap">
      <Row>
      <Col span="4">
      <div class="leftmenu">
        <ul class="nav">
          <li class="divider">{{$t('cms.about')}}</li>
          <li><router-link to="/about-us">{{$t('cms.aboutus')}}</router-link></li>
          <li class="cur"><router-link to="/join-us">{{$t('cms.joinus')}}</router-link></li>
        </ul>
      </div>
      </Col>
      <Col span="20">
      <div class="content">

          <div class=WordSection1 style='layout-grid:15.6pt'>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>&nbsp;</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span style='font-family:
Microsoft YaHei;color:black'>如果你曾经梦想改变这个世界，而同时你又对互联网金融行业及区块链技术有浓厚的兴趣，</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span style='font-family:
Microsoft YaHei;color:black'>最好再对币圈有所了解，那么欢迎你加入<span lang=EN-US>Cayman</span>，让我们共同打造全球顶尖的数字资产交易平台。</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>&nbsp;</span></p>

          <p class=MsoNormal align=left style='text-align:left'><b><span
            style='color:black'>高级产品经理</span></b></p>

          <p class=MsoNormal align=left style='text-align:left'><span style='font-family:
Microsoft YaHei;color:black'>岗位职责：</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>1.</span><span style='
color:black'>负责公司数字币交易产品的发展规划及核心模块设计；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>2.</span><span style='
color:black'>设计、利用数据回收机制，指导产品优化并进行迭代效果监控；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>3.</span><span style='
color:black'>负责竞争产品、行业产品、行业相关信息的收集整理和深度分析；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>4.</span><span style='
color:black'>对产品生命周期进行分析、测算，对产品的长期发展战略提出建设性意见，为公司决策层提供参考依据；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span style='font-family:
Microsoft YaHei;color:black'>任职要求：</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>1.</span><span style='
color:black'>对互联网金融行业及区块链技术具有强烈兴趣，并对所面向的用户群体具有较为深刻的认知；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>2.</span><span style='
color:black'>熟悉互联网产品整体实现过程，包括从需求分析到产品发布。有敏锐的市场洞察能力，严密的逻辑分析能力，良好的沟通协作能力，以及一定的技术理解能力；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>3.</span><span style='
color:black'>具有较强的目标导向意识和执行力，能领导并指导产品团队高效完成目标；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>4.</span><span style='
color:black'>能很好的控制项目进度和质量，协调相关人员共同完成任务；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>5.</span><span style='
color:black'>具有优秀的交互设计功底，在用户体验设计上追求极致；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>6.3</span><span style='
color:black'>年及以上互联网产品经验，有行业相关产品经验者优先。</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>&nbsp;</span></p>

          <p class=MsoNormal align=left style='text-align:left'><b><span
            style='color:black'>移动端资深<span lang=EN-US>/</span>高级产品经理</span></b></p>

          <p class=MsoNormal align=left style='text-align:left'><span style='font-family:
Microsoft YaHei;color:black'>岗位职责：</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>1.</span><span style='
color:black'>负责公司移动端数字资产交易产品的发展规划及核心模块设计；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>2.</span><span style='
color:black'>设计、利用数据回收机制，指导产品优化并进行迭代效果监控；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>3.</span><span style='
color:black'>负责竞争产品、行业产品、行业相关信息的收集整理和深度分析；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>4.</span><span style='
color:black'>对产品生命周期进行分析、测算，对产品的长期发展战略提出建设性意见，为公司决策层提供参考依据。</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span style='font-family:
Microsoft YaHei;color:black'>任职要求：</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>1.</span><span style='
color:black'>对互联网金融行业及区块链技术具有强烈兴趣，并对所面向的用户群体具有较为深刻的认知；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>2.</span><span style='
color:black'>熟悉互联网产品整体实现过程，包括从需求分析到产品发布，有敏锐的市场洞察能力，严密的逻辑分析能力，良好的沟通协作能力，以及一定的技术理解能力；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>3.</span><span style='
color:black'>具有较强的目标导向意识和执行力，能领导并指导产品团队高效完成目标；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>4.</span><span style='
color:black'>能很好的控制项目进度和质量，协调相关人员共同完成任务；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>5.</span><span style='
color:black'>具有优秀的交互设计功底，在用户体验设计上追求极致；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>6.5</span><span style='
color:black'>年及以上互联网产品经验，有行业相关产品经验者优先<span lang=EN-US>;</span></span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>&nbsp;</span></p>

          <p class=MsoNormal align=left style='text-align:left'><b><span
            style='color:black'>产品助理</span></b></p>

          <p class=MsoNormal align=left style='text-align:left'><span style='font-family:
Microsoft YaHei;color:black'>岗位职责：</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>1.</span><span style='
color:black'>负责对竞品、行业产品、行业相关信息的收集分析；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>2.</span><span style='
color:black'>负责产品效果相关的反馈和整理，并输出可用性效果建议；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>3.</span><span style='
color:black'>协助部门负责人完成部门内的常规工作。</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span style='font-family:
Microsoft YaHei;color:black'>任职要求：</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>1.</span><span style='
color:black'>统招本科以上学历；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>2.</span><span style='
color:black'>应届生优先考虑；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>3. </span><span style='
color:black'>对互联网金融行业及区块链技术感兴趣。</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>&nbsp;</span></p>

          <p class=MsoNormal align=left style='text-align:left'><b><span
            style='color:black'>资深<span lang=EN-US>/</span>高级<span
            lang=EN-US>UI</span>设计师</span></b></p>

          <p class=MsoNormal align=left style='text-align:left'><span style='font-family:
Microsoft YaHei;color:black'>岗位职责：</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>1.</span><span style='
color:black'>负责金融类产品的视觉设计工作，提供全局的设计方案；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>2.</span><span style='
color:black'>参与产品讨论、交互设计，推动技术还原界面设计，检查并修正设计问题，对最终效果负责；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>3.</span><span style='
color:black'>参与并制定设计原则和规范，达成统一的产品视觉风格。</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span style='font-family:
Microsoft YaHei;color:black'>任职要求：</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>1.</span><span style='
color:black'>设计相关专业毕业，熟练使用相关设计工具；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>2.</span><span style='
color:black'>丰富的网页及移动端产品的视觉设计经验，有成功的市场案例者优先考虑；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>3.</span><span style='
color:black'>对<span lang=EN-US>UI</span>设计趋势有灵敏触觉和领悟能力；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>4.</span><span style='
color:black'>熟悉相关交互设计及用户研究方法和工作流程，能够独立支持产品的设计工作；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>5.</span><span style='
color:black'>关注细节，追求极致体验；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>6.</span><span style='
color:black'>具备良好合作态度及团队精神，富有工作激情<span lang=EN-US>. </span>创造力和责任感。</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>&nbsp;</span></p>

          <p class=MsoNormal align=left style='text-align:left'><b><span
            style='color:black'>英文翻译</span></b></p>

          <p class=MsoNormal align=left style='text-align:left'><span style='font-family:
Microsoft YaHei;color:black'>岗位职责：</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>1.</span><span style='
color:black'>负责日常英语业务的翻译；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>2.</span><span style='
color:black'>海外行业市场信息搜集与翻译；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>3.</span><span style='
color:black'>英文邮件沟通与翻译。</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span style='font-family:
Microsoft YaHei;color:black'>任职要求：</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>1.</span><span style='
color:black'>本科及以上学历，文字翻译功底深厚；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>2.</span><span style='
color:black'>互联网金融背景优先；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>3.</span><span style='
color:black'>有中文基础的外籍人士，熟悉中英互译优先；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>4.</span><span style='
color:black'>有海外留学背景、海外生活经历、拥有海外资源者优先。</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>&nbsp;</span></p>

          <p class=MsoNormal align=left style='text-align:left'><b><span
            style='color:black'>平面设计师</span></b></p>

          <p class=MsoNormal align=left style='text-align:left'><span style='font-family:
Microsoft YaHei;color:black'>岗位职责：</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>1.</span><span style='
color:black'>负责公司品牌形象规范系统的维护与更新工作；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>2.</span><span style='
color:black'>独立完成公司线上线下平面宣传设计，包括<span lang=EN-US>banner</span>，产品宣传册，平面广告包装，海报，活动图等创意设计与制作；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>3.</span><span style='
color:black'>规范公司<span lang=EN-US>VI</span>视觉形象并具有自己独特想法，可规划出公司品牌衍生品；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>4.</span><span style='
color:black'>公司品牌宣传设计：包括节假日礼品物料以及所有公司宣传相关物料； </span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>5.</span><span style='
color:black'>负责设计公司线下活动主视觉以及相关物料延展；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>6.</span><span style='
color:black'>负责公司互联网新媒体的线上传播的模版设计以及画面的美化；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>7.</span><span style='
color:black'>配合协助产品设计部的日常创意工作；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>8.</span><span style='
color:black'>根据相关业务部门的具体需求，提供设计支持。</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span style='font-family:
Microsoft YaHei;color:black'>任职要求：</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>1.3</span><span style='
color:black'>年以上设计行业经验，有完整的创意执行工作经验；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>2.</span><span style='
color:black'>广告设计类相关专业，接受过正规美术教育；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>3.</span><span style='
color:black'>熟练使用<span lang=EN-US>Photoshop</span>／<span lang=EN-US>illustrator</span>／<span
            lang=EN-US>CoreIDRAW</span>／<span lang=EN-US>Sketch</span>／<span lang=EN-US>Indesign</span>等常用设计软件；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>4.</span><span style='
color:black'>精通印刷物品出版，熟悉相关流程；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>5.</span><span style='
color:black'>对设计有高度热情，对前沿的设计有敏锐的洞察力；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>6.</span><span style='
color:black'>具有一定的金融行业知识；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>7.</span><span style='
color:black'>具有较强的设计需求分析能力和良好的沟通能力。</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>&nbsp;</span></p>

          <p class=MsoNormal align=left style='text-align:left'><b><span
            style='color:black'>高级<span lang=EN-US>JAVA</span>开发工程师</span></b></p>

          <p class=MsoNormal align=left style='text-align:left'><span style='font-family:
Microsoft YaHei;color:black'>岗位职责：</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>1.</span><span style='
color:black'>调研和研发下一代比特币交易所和相关系统；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>2.</span><span style='
color:black'>创建性能指标；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>3.</span><span style='
color:black'>依据反馈快速迭代；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>4.</span><span style='
color:black'>在小团队中工作<span lang=EN-US>, </span>可能会参与不同层级的开发；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span style='font-family:
Microsoft YaHei;color:black'>任职要求：</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>1.</span><span style='
color:black'>能够熟练使用<span lang=EN-US>java</span>；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>2.</span><span style='
color:black'>有多年实际编写代码的经验；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>3.</span><span style='
color:black'>理解基本的关系数据库知识；</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span style='font-family:
Microsoft YaHei;color:black'>可选技能：</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span style='font-family:
Microsoft YaHei;color:black'>贡献开源代码或者维护一个技术博客</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span style='font-family:
Microsoft YaHei;color:black'>有区块链<span lang=EN-US>(</span>比特币以太坊<span lang=EN-US>)</span>的开发经验</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span style='font-family:
Microsoft YaHei;color:black'>有能力开发和排查多线程代码</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span style='font-family:
Microsoft YaHei;color:black'>有<span lang=EN-US> JVM </span>开发<span lang=EN-US>, </span>配置<span
            lang=EN-US>, </span>调优的经验</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span style='font-family:
Microsoft YaHei;color:black'>有优化既有程序的经验</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span style='font-family:
Microsoft YaHei;color:black'>具备独立开发单独模块的能力</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span style='font-family:
Microsoft YaHei;color:black'>具备较强的交流能力并且能够跟跨功能团队协作开发</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>&nbsp;</span></p>

          <p class=MsoNormal align=left style='text-align:left'><b><span
            style='color:black'>工作地点</span></b></p>

          <p class=MsoNormal align=left style='text-align:left'><span style='font-family:
Microsoft YaHei;color:black'>我们正在以下地点招兵买马，优先顺序依次如下：香港、新加坡、日本、欧洲、南美及其它国家。</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>&nbsp;</span></p>

          <p class=MsoNormal align=left style='text-align:left'><b><span
            style='color:black'>联系我们</span></b></p>

          <p class=MsoNormal align=left style='text-align:left'><span style='font-family:
Microsoft YaHei;color:black'>若要申请上述职位，请将您的简历和求职信发送至<span lang=EN-US>hr@caymanex.pro</span>。请在邮件主题中注明希望的职位和工作地点。</span></p>

          <p class=MsoNormal align=left style='text-align:left'><span lang=EN-US
                                                                      style='color:black'>&nbsp;</span></p>

        </div>

      </div>
      </Col>
      </Row>
    </div>
  </div>
</template>

<style scoped>
  .postlist li{
    float: left;
    width: 50%;
  }
  li.header{
    width: 100%;
    text-align: center;
    font-size: 16px;
    padding: 10px;
    background: #ccc;
  }
  .postlist ul:after{
    content: ' ';
    clear: both;
    display: block;
  }
  .container{
    background: #fff;
    overflow-x:hidden;
  }
  .content-wrap{
    padding-top: 20px;
    position: relative;
    width: 1200px;
    margin: 0 auto;
    background: #fff;
  }
  .leftmenu{
    /*position: absolute;*/
    /*width: 180px;*/
    /*text-align: center;*/
    border: 1px solid #efefef;
  }
  .leftmenu .divider{
    font-size: 20px;
    padding: 5px;
    background: #efefef;
  }
  .leftmenu li {
    font-size: 14px;
    line-height: 30px;
    padding: 5px;
  }
  .leftmenu li a{
    color: #444;
  }
  .leftmenu li a:hover{
    color: #3399ff
  }
  .leftmenu li.cur a {
    color: #3399ff
  }
  .content {
    padding-top: 20px;
    /*padding-left: 200px;*/
    padding-bottom: 20px;
    text-align: left;
    padding-left: 20px;
  }
  .content p{
    text-indent: 2em;
    margin-bottom: 10px;
    font-size: 14px;
  }
  .content>div{
    padding-bottom: 20px;
  }
  .content h3{
    font-size: 22px;
    font-weight: normal;
    margin-bottom: 20px;
  }
  .content h5 {
    font-size: 14px;
  }
  .WordSection1 span{ color:black;    font-family: Microsoft YaHei;}
</style>

//
//  ZLGestureLockIndicator.h
//  GestureLockDemo
//
//  Created by ZL on 2017/4/5.
//  Copyright © 2017年 ZL. All rights reserved.
//  九宫格指示器 小图

#import <UIKit/UIKit.h>

@interface ZLGestureLockIndicator : UIView

- (void)setGesturePassword:(NSString *)gesturePassword;

@end

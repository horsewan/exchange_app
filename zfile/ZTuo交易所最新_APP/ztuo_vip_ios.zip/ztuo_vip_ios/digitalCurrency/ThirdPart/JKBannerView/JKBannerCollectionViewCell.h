//
//  JKBannerCollectionViewCell.h
//
//  Created by 王冲 on 2017/9/8.
//  Copyright © 2017年 yangsq. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JKBannerCollectionViewCell : UICollectionViewCell

@property (nonatomic,strong) UIImageView *imageView;

@end

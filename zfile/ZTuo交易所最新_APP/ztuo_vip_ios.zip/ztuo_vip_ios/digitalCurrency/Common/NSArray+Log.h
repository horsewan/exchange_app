//
//  NSArray+Log.h
//  ReadingClub
//
//  Created by qtkj on 16/9/1.
//  Copyright © 2016年 qtkj. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSArray (Log)

@end

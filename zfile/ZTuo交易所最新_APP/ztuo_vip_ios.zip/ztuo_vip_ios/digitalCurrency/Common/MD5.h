//
//  MD5.h
//  digitalCurrency
//
//  Created by sunliang on 2018/4/4.
//  Copyright © 2018年 ztuo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MD5 : NSObject
+(NSString *) md5: (NSString *) inPutText;
@end

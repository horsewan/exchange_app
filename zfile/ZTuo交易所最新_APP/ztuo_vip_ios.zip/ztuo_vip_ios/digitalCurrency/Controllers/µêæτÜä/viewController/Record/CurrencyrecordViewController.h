//
//  CurrencyrecordViewController.h
//  digitalCurrency
//
//  Created by startlink on 2018/8/7.
//  Copyright © 2018年 ztuo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CurrencyrecordViewController : UIViewController

@end

//
//  AboutUSModel.m
//  digitalCurrency
//
//  Created by iDog on 2018/3/21.
//  Copyright © 2018年 ztuo. All rights reserved.
//

#import "AboutUSModel.h"

@implementation AboutUSModel

+(NSDictionary *)mj_replacedKeyFromPropertyName{
    return @{@"ID":@"id",@"describe":@"description"};
}
@end

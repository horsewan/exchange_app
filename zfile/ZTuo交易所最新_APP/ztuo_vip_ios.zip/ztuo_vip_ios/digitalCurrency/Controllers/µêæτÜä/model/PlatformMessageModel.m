//
//  PlatformMessageModel.m
//  digitalCurrency
//
//  Created by iDog on 2018/3/1.
//  Copyright © 2018年 ztuo. All rights reserved.
//

#import "PlatformMessageModel.h"

@implementation PlatformMessageModel

+(NSDictionary *)mj_replacedKeyFromPropertyName{
    return @{@"ID":@"id"};
}
@end

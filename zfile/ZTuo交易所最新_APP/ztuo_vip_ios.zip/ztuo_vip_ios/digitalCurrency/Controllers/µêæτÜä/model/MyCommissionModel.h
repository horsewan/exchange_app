//
//  MyCommissionModel.h
//  digitalCurrency
//
//  Created by iDog on 2018/5/7.
//  Copyright © 2018年 ztuo. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MyCommissionModel : NSObject
@property(nonatomic,copy)NSString *amount;
@property(nonatomic,copy)NSString *createTime;
@property(nonatomic,copy)NSString *remark;
@property(nonatomic,copy)NSString *symbol;
@end

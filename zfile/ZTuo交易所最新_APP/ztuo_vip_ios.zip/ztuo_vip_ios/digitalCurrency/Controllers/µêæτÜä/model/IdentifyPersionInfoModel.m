//
//  IdentifyPersionInfoModel.m
//  digitalCurrency
//
//  Created by iDog on 2018/4/13.
//  Copyright © 2018年 ztuo. All rights reserved.
//

#import "IdentifyPersionInfoModel.h"

@implementation IdentifyPersionInfoModel

@end

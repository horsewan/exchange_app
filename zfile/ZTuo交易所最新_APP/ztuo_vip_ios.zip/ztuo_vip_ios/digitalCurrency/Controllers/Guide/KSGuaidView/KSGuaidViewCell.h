//
//  KSGuaidViewCell.h
//  KSGuaidViewDemo
//
//  Created by Mr.kong on 2017/5/24.
//  Copyright © 2017年 iCloudys. All rights reserved.
//

#import <UIKit/UICollectionViewCell.h>
#import <UIKit/UIImageView.h>
@interface KSGuaidViewCell : UICollectionViewCell

@property (nonatomic, strong) UIImageView* imageView;

@end

UIKIT_EXTERN NSString * const KSGuaidViewCellID;

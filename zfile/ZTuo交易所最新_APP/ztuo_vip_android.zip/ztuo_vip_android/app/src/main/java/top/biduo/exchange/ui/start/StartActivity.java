package top.biduo.exchange.ui.start;

import android.os.Bundle;

import top.biduo.exchange.R;
import top.biduo.exchange.base.BaseActivity;

public class StartActivity extends BaseActivity {
    @Override
    protected int getActivityLayoutId() {
        return R.layout.activity_start;
    }

    @Override
    protected void initViews(Bundle savedInstanceState) {

    }

    @Override
    protected void obtainData() {

    }

    @Override
    protected void fillWidget() {

    }

    @Override
    protected void loadData() {

    }
}

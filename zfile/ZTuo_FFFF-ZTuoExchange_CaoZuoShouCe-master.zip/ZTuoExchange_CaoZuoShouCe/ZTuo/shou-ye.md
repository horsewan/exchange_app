1. 用户进入平台后，默认进入首页，如图![](/ZTuo/assets/import52.png)
2. 页面最上方左侧显示当前系统时间及时区、右侧显示APP下载（点击显示交易所APP下载二维码）。如图![](/ZTuo/assets/import29.png)
3. 系统时间下方显示banner图，图片顶部显示logo及导航栏，列出了系统的主要功能模块，包括[首页](/ZTuo/shou-ye.md)、[币币交易](/ZTuo/bi-bi-jiao-yi.md)、[法币交易](/ZTuo/fa-bi-jiao-yi.md)、[帮助](/ZTuo/bang-zhu.md)、[公告](/ZTuo/gong-gao.md)、[登录](/ZTuo/deng-lu.md)、[注册](/ZTuo/gai-shu.md)七个模块，点击每个功能模块的导航链接即可进入相应功能模块进行操作（若已登录，则登录、注册位置显示[个人中心](/ZTuo/ge-ren-zhong-xin.md)、及登录的用户名，点击用户名，可退出交易所）。如图![](/ZTuo/assets/import23.png)
4. banner图下方显示系统公告，点击可进入详情页；点击更多可进入公告列表页。如图![](/ZTuo/assets/import25.png)
5. 下方区域显示当前系统的数字资产交易对的实时信息。如图![](/ZTuo/assets/import26.png)点击“去交易”下方的交易图标，可进入该交易对的[币币交易](/ZTuo/bi-bi-jiao-yi.md)页面。  
   点击星号图标，可收藏或取消收藏该交易对（需登录后才可收藏）。自选tab页中，显示已收藏的交易对信息。

6. 页面最下方显示APP下载二维码及底部导航栏，扫描二维码可下载交易所的Android APP和IOS，点击导航栏可链接到相应页面。如图![](/ZTuo/assets/import27.png)




1. 登录平台后，点击页面右上角的个人中心，进入个人中心页面（默认显示账户管理---实名认证页面）。![](/ZTuo/assets/import7.png)

2. 个人中心有四个小模块：[账户管理](/ZTuo/ge-ren-zhong-xin/zhang-hu-guan-li.md)、[资产管理](/ZTuo/ge-ren-zhong-xin/zi-chan-guan-li.md)、[币币管理](/ZTuo/ge-ren-zhong-xin/bi-bi-guan-li.md)、[法币管理](/ZTuo/ge-ren-zhong-xin/fa-bi-guan-li.md)




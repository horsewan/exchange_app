1. 进入交易所首页，点击右上角的“注册”。 如图所示。![](/ZTuo/assets/import1.png)
2. 进入“注册新用户”页面，如图![](/ZTuo/assets/zhuce2.png)
3. 可点击查看“用户协议”，如图![](/ZTuo/assets/import3.png)
4. 填写完注册信息后，点击“注册”按钮，若用户填写的信息正确，会进入“[登录](/ZTuo/deng-lu.md)”页面。




package com.ztuo.bc.wallet;

import org.junit.Test;

public class AddressTest extends BaseTest{
    @Test
    public void testFind(){
    }
}

package com.ztuo.bc.wallet.component;

public interface WatchListener {
    void block();
    void transaction();
}
